import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  private name: string;

  constructor(public navCtrl: NavController, private localStorage: Storage) {
    localStorage.set('name', 'Lawrence Zhou');
  }

  showLocalStorage() {
    this.localStorage.get('name').then((data) => {
      console.log('name: ' + data);
      this.name = data;
    });
  }
}
